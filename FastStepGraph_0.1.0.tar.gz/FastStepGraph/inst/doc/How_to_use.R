## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
options(rmarkdown.html_vignette.check_title = FALSE)

## ----setup--------------------------------------------------------------------
library(FastStepGraph)
library(MASS)     # mvrnorm

# If you directly cloned the github repository, then you should uncomment these lines to load the functions:
# source('FastStepGraph.R')
# source('SigmaAR.R')

## -----------------------------------------------------------------------------
set.seed(1234567)
phi <- 0.4 
p <- 100  # number of variables (dimension)
n <- 50 # number of samples

Sigma <- SigmaAR(p, phi)
Omega <- solve(Sigma)  
Omega[abs(Omega) < 1e-5] <- 0  

# Generate Data from a Gaussian distribution 
X <- list()
X <- MASS::mvrnorm(n, mu=rep(0,p), Sigma)
X <- scale(X) # data normalization to zero mean and unit variance 

## -----------------------------------------------------------------------------
t0 <- Sys.time() # INITIAL TIME
G <- FastStepGraph(X, alpha_f = 0.22, alpha_b = 0.14)
difftime(Sys.time(), t0, units = "secs")
# print(G$Omega)

## -----------------------------------------------------------------------------
t0 <- Sys.time() # INITIAL TIME
res <- cv.FastStepGraph(X, data_shuffle = FALSE)
difftime(Sys.time(), t0, units = "secs")

print(res$alpha_f_opt)
print(res$alpha_b_opt)
# print(res$Omega)

## -----------------------------------------------------------------------------
# t0 <- Sys.time() # INITIAL TIME
# res <- cv.FastStepGraph(X, parallel = TRUE)
# difftime(Sys.time(), t0, units = "secs")

# print(res$alpha_f_opt)
# print(res$alpha_b_opt)
# print(res$Omega)

